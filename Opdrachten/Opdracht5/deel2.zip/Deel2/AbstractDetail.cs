namespace deel2
{
    public abstract class AbstractDetail
    {
        private string detail;

        public abstract void GeefDetail();

    }
}
