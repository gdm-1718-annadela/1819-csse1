namespace deel2
{
    public abstract class AbstractInfo
    {
        private string info;

        public string InfoDetail
        {
            get;
            set;
        }

        //public 
        public abstract void GeefInformatie();
        //public abstract string GeefInformatie();

    }
}
