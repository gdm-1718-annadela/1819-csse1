namespace deel2
{
    public interface IInformatie
    {
        //private string type;
        //public 
        /* string GroepType
        {
            get;
            set;
        } */
        string ToString();
    }
}

